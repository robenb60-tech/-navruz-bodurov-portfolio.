ПОРТФОЛИО НАВРУЗА БОДУРОВА

ФАЙЛЫ
- index.html — сайт
- style.css — оформление и адаптация для телефонов
- script.js — фильтры, раскрытие опыта, копирование телефона

ПРОСМОТР ЛОКАЛЬНО
Распакуйте архив и откройте index.html в браузере.

БЕСПЛАТНАЯ ПУБЛИКАЦИЯ ЧЕРЕЗ GITHUB PAGES
1. Откройте https://github.com и войдите или зарегистрируйтесь.
2. Нажмите New repository.
3. Назовите репозиторий navruz-bodurov-portfolio, выберите Public и Create repository.
4. Нажмите Add file → Upload files.
5. Загрузите index.html, style.css и script.js из архива (не сам ZIP).
6. Нажмите Commit changes.
7. Откройте Settings → Pages.
8. В разделе Build and deployment выберите Deploy from a branch.
9. Выберите Branch: main и Folder: / (root), нажмите Save.
10. Подождите несколько минут. В разделе Pages появится адрес сайта.
Обычно он выглядит так: https://ВАШ-ЛОГИН.github.io/navruz-bodurov-portfolio/

ПЕРЕД ПУБЛИКАЦИЕЙ
Проверьте контактные данные, даты и формулировки. Публикация сайта делает указанные телефон и email доступными всем посетителям.
Фотография не используется. Для красивого шрифта сайт загружает Google Fonts; без интернета будут системные шрифты.

КОНТАКТЫ
+(992) 111-172-966
robenb60@gmail.com
